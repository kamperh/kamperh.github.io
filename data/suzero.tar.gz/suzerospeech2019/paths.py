buckeye_datadir = "/home/kamperh/endgame/datasets/buckeye/"
zerospeech2019_datadir = "/home/kamperh/endgame/datasets/zerospeech2019/shared/databases/"
