This data was compiled by [Herman Kamper](https://www.kamperh.com) from content
on the [Siyavula website](https://www.siyavula.com/read). It is released under
the [CC BY](https://creativecommons.org/licenses/by/3.0/) license, with credit
to Siyavula for the content and Herman Kamper for the data compilation.
