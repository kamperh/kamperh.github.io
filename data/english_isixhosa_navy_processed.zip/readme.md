isiXhosa - English Translations from the Naval Domain
=====================================================

Overview
--------
This is a parallel corpus of isiXhosa - English text translations from the
South African naval domain. Originally provided by Herman A. Engelbrecht from
Stellenbosch University. Processed by Herman Kamper from Stellenbosch
University.

Each new line of `english_navy_processed.txt` corresponds to a line in
`isixhosa_navy_processed.txt`. The files are encoded using ISO-8859-1.


License
-------
The data is distributed under the Creative Commons Attribution-ShareAlike
license ([CC BY-SA 4.0](http://creativecommons.org/licenses/by-sa/4.0/)).
